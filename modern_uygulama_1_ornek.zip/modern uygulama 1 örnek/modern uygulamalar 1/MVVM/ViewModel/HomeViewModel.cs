﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace modern_uygulamalar_1.MVVM.ViewModel
{
    internal class HomeViewModel
    {
    }
}
